# Bloomy Battery Simulator 1200 Python Driver

This package enables CAN communication to the Bloomy BS1200 through the PEAK Systems PCAN-USB FD adapter. 
# README TODO
## feature list
## use instructions